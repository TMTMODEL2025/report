import React, { useState, useMemo } from 'react';
import { RepairItem, MonthlyGroup, WeeklyData, TypeStats, VehicleStats } from './types';
import { formatDate, formatPrice, calculateTotalCost, calculateTotalSparePartsPrice, getSplitArray, getThaiMonthName, groupDataByMonth, parseDate, groupDataByWeek, processTypeData, processVehicleData } from './utils';

// ========== ICONS ==========
export const Icons: React.FC<{ name: string; className?: string }> = ({ name, className = 'h-5 w-5' }) => {
    const iconMap: { [key: string]: React.ReactNode } = {
        expand: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />,
        collapse: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7" />,
        refresh: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />,
        test: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />,
        chevronDown: <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />,
        // New icons for bottom nav
        list: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />,
        calendar: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />,
        pieChart: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />,
        truck: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v-4M4 16V6a2 2 0 012-2h8a2 2 0 012 2v10m-6 2h2m-4-2a2 2 0 100-4 2 2 0 000 4z" />

    };
    return (
        <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {iconMap[name]}
        </svg>
    );
};

// ========== LOADER ==========
export const Loader: React.FC = () => (
    <div className="text-center py-8">
        <div className="border-[5px] border-solid border-gray-200 border-t-blue-500 rounded-full w-12 h-12 animate-spin mx-auto"></div>
        <p className="mt-4 text-gray-600">กำลังโหลดข้อมูล...</p>
    </div>
);

// ========== Summary Card ==========
interface SummaryCardProps {
    title: string;
    value: string | number;
    color: 'blue' | 'green' | 'purple' | 'amber';
    unit?: string;
}
export const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, color, unit }) => {
    const colors = {
        blue: { bg: 'bg-blue-100', text: 'text-blue-800', value: 'text-blue-900 font-bold' },
        green: { bg: 'bg-green-100', text: 'text-green-800', value: 'text-green-900 font-bold' },
        purple: { bg: 'bg-purple-100', text: 'text-purple-800', value: 'text-purple-900 font-bold' },
        amber: { bg: 'bg-amber-100', text: 'text-amber-800', value: 'text-amber-900 font-bold' },
    };
    return (
        <div className={`${colors[color].bg} p-3 sm:p-4 rounded-lg shadow`}>
            <h3 className={`font-semibold ${colors[color].text} text-sm sm:text-base`}>{title}</h3>
            <p className={`text-2xl sm:text-3xl ${colors[color].value}`}>{value} <span className="text-lg font-medium">{unit}</span></p>
        </div>
    );
};

// ========== Bar Chart ==========
interface BarChartProps {
    data: { label: string, value: number, displayValue: string }[];
    color: string;
    title: string;
}

export const BarChart: React.FC<BarChartProps> = ({ data, color, title }) => {
    const maxValue = Math.max(...data.map(d => d.value), 0);
    return (
        <div className="bg-white rounded-lg shadow-md p-3 sm:p-4">
            <h3 className="font-semibold text-base sm:text-lg mb-3 sm:mb-4 text-slate-800">{title}</h3>
            <div className="mt-4 space-y-3">
                {data.map((item, index) => (
                    <div key={index} className="chart-container flex items-center text-sm">
                        <div className="w-1/3 sm:w-1/4 font-medium truncate pr-2 text-slate-700">{item.label}</div>
                        <div className="w-2/3 sm:w-3/4 flex items-center">
                            <div className={`chart-bar rounded-sm ${color}`} style={{ width: maxValue > 0 ? `${(item.value / maxValue) * 100}%` : '0%', height: '24px' }}></div>
                            <span className="ml-2 whitespace-nowrap font-medium text-slate-700">{item.displayValue}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

// ========== ALL DATA TAB ==========
interface AllDataTabProps {
    data: RepairItem[];
    isMobile: boolean;
}

const RepairTableRow: React.FC<{ item: RepairItem; index: number }> = ({ item, index }) => {
    const totalCost = calculateTotalCost(item);
    return (
        <tr className="odd:bg-white even:bg-slate-50 hover:bg-blue-100/50 text-sm">
            <td className="border-b border-gray-200 px-4 py-3 text-slate-600">{index}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-800 font-medium">{item['เบอร์รถ']}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{item['รายการซ่อม']}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{item['ประเภท']}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{formatDate(item['วันที่แจ้งซ่อม(APP)'])}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{formatDate(item['ซ่อมเสร็จ(APP)'])}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right text-slate-700">{formatPrice(calculateTotalSparePartsPrice(item['ราคาอะไหล่']))}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right text-slate-700">{formatPrice(item['ราคา'])}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right font-bold text-emerald-600">{formatPrice(totalCost)}</td>
        </tr>
    );
};

const RepairCard: React.FC<{ item: RepairItem; index: number }> = ({ item, index }) => {
    const totalCost = calculateTotalCost(item);
    const sparePartsPrice = calculateTotalSparePartsPrice(item['ราคาอะไหล่']);
    const servicePrice = parseFloat(String(item['ราคา'])) || 0;

    return (
        <div className="mobile-card border border-gray-200 rounded-lg mb-4 p-4 bg-white shadow">
            <div className="flex justify-between items-center mb-2">
                <div className="font-semibold text-slate-800">#{index} - {item['เบอร์รถ']}</div>
                <div className="text-right">
                    <div className="font-bold text-emerald-600">{formatPrice(totalCost)}</div>
                    <div className="text-xs text-gray-500">ต้นทุนรวม</div>
                </div>
            </div>
            <div className="mb-2 text-sm">
                <div className="font-medium text-slate-700">{item['รายการซ่อม']}</div>
                <div className="text-blue-600 font-medium">{item['ประเภท']}</div>
            </div>
            <div className="grid grid-cols-2 gap-1 text-xs text-gray-600 mb-2">
                <div>แจ้งซ่อม: {formatDate(item['วันที่แจ้งซ่อม(APP)'])}</div>
                <div>ซ่อมเสร็จ: {formatDate(item['ซ่อมเสร็จ(APP)'])}</div>
            </div>
            <div className="bg-gray-50 p-2 rounded text-xs">
                <div className="flex justify-between"><span>ราคาอะไหล่:</span> <span>{formatPrice(sparePartsPrice)}</span></div>
                <div className="flex justify-between"><span>ราคาซ่อม:</span> <span>{formatPrice(servicePrice)}</span></div>
            </div>
        </div>
    );
};


const MonthGroupSection: React.FC<{ monthKey: string; group: MonthlyGroup; isMobile: boolean; onToggle: () => void; isExpanded: boolean; }> = ({ monthKey, group, isMobile, onToggle, isExpanded }) => {
    const monthName = getThaiMonthName(group.month) + ' ' + group.year;
    return (
        <div className="mb-4 bg-white rounded-lg shadow-md overflow-hidden">
            <div onClick={onToggle} className="month-header bg-blue-50 px-4 py-3 flex justify-between items-center cursor-pointer hover:bg-blue-100 transition-colors duration-200">
                <div className="flex items-center">
                    <span className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-0' : '-rotate-90'}`}>
                        <Icons name="chevronDown" className="h-5 w-5 mr-2 text-blue-600" />
                    </span>
                    <h3 className="font-semibold text-blue-800">{monthName}</h3>
                </div>
                <div className="text-sm text-slate-700">
                    <span className="font-semibold text-slate-800">{group.items.length}</span> รายการ | <span className="font-semibold text-slate-800">{formatPrice(group.totalPrice)}</span> บาท
                </div>
            </div>
            <div className={`month-content transition-all duration-300 ease-in-out overflow-hidden ${isExpanded ? 'max-h-[10000px] opacity-100' : 'max-h-0 opacity-50'}`}>
                 <div className="p-0 sm:p-0">
                    {isMobile ? (
                        <div className="p-2">{group.items.map((item, idx) => <RepairCard key={item['ลำดับที่']} item={item} index={idx + 1}/>)}</div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full border-collapse">
                                <thead>
                                    <tr className="bg-slate-100">
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ลำดับที่</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">เบอร์รถ</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">รายการซ่อม</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ประเภท</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">วันที่แจ้งซ่อม</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ซ่อมเสร็จ</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-semibold text-slate-800 uppercase tracking-wider">ราคาอะไหล่</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-semibold text-slate-800 uppercase tracking-wider">ราคาซ่อม</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-semibold text-slate-800 uppercase tracking-wider">ต้นทุนรวม</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {group.items.map((item, idx) => <RepairTableRow key={item['ลำดับที่']} item={item} index={idx + 1}/>)}
                                </tbody>
                            </table>
                        </div>
                    )}
                 </div>
            </div>
        </div>
    );
};

export const AllDataTab: React.FC<AllDataTabProps> = ({ data, isMobile }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterType, setFilterType] = useState('');
    const [filterYear, setFilterYear] = useState('');
    const [expandedMonths, setExpandedMonths] = useState<Set<string>>(new Set());

    const { uniqueTypes, uniqueYears } = useMemo(() => {
        const types = new Set<string>();
        const years = new Set<number>();
        data.forEach(item => {
            if (item.ประเภท) types.add(item.ประเภท);
            const date = new Date(item['วันที่แจ้งซ่อม(APP)']);
            if (!isNaN(date.getTime())) years.add(date.getFullYear());
        });
        return { uniqueTypes: Array.from(types).sort(), uniqueYears: Array.from(years).sort((a, b) => b - a) };
    }, [data]);

    const filteredData = useMemo(() => {
        return data.filter(item => {
            const date = new Date(item['วันที่แจ้งซ่อม(APP)']);
            const itemYear = !isNaN(date.getTime()) ? date.getFullYear().toString() : '';

            const matchesSearch = searchTerm === '' || Object.values(item).some(val => String(val).toLowerCase().includes(searchTerm.toLowerCase()));
            const matchesType = filterType === '' || item.ประเภท === filterType;
            const matchesYear = filterYear === '' || itemYear === filterYear;
            
            return matchesSearch && matchesType && matchesYear;
        });
    }, [data, searchTerm, filterType, filterYear]);

    const groupedData = useMemo(() => {
        return Object.entries(groupDataByMonth(filteredData)).sort(([keyA], [keyB]) => {
            const datePartsA = keyA.split('-');
            const datePartsB = keyB.split('-');
            const dateA = new Date(Number(datePartsA[0]), Number(datePartsA[1]));
            const dateB = new Date(Number(datePartsB[0]), Number(datePartsB[1]));
            return dateB.getTime() - dateA.getTime();
        });
    }, [filteredData]);

    const toggleMonth = (monthKey: string) => {
        setExpandedMonths(prev => {
            const newSet = new Set(prev);
            if (newSet.has(monthKey)) {
                newSet.delete(monthKey);
            } else {
                newSet.add(monthKey);
            }
            return newSet;
        });
    };
    
    const expandAll = () => setExpandedMonths(new Set(groupedData.map(([key]) => key)));
    const collapseAll = () => setExpandedMonths(new Set());
    
    const totalCost = useMemo(() => filteredData.reduce((sum, item) => sum + calculateTotalCost(item), 0), [filteredData]);

    return (
        <div>
            <div className="mb-4 sm:mb-6">
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                    <input type="text" placeholder="ค้นหา..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto" />
                    <select value={filterType} onChange={e => setFilterType(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto">
                        <option value="">ทุกประเภท</option>
                        {uniqueTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <select value={filterYear} onChange={e => setFilterYear(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto">
                        <option value="">ทุกปี</option>
                        {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                </div>
                <div className="mt-2 flex gap-2">
                    <button onClick={expandAll} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition w-full sm:w-auto text-sm flex items-center justify-center">
                        <Icons name="expand" className="h-4 w-4 mr-1"/> ขยายทั้งหมด
                    </button>
                    <button onClick={collapseAll} className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md transition w-full sm:w-auto text-sm flex items-center justify-center">
                        <Icons name="collapse" className="h-4 w-4 mr-1"/> ย่อทั้งหมด
                    </button>
                </div>
            </div>

            <div id="monthlyDataContainer">
                {groupedData.length > 0 ? (
                    groupedData.map(([key, group]) => (
                        <MonthGroupSection key={key} monthKey={key} group={group as MonthlyGroup} isMobile={isMobile} isExpanded={expandedMonths.has(key)} onToggle={() => toggleMonth(key)} />
                    ))
                ) : (
                    <div className="text-center py-8 text-gray-500">ไม่พบข้อมูล</div>
                )}
            </div>

            <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-sm sm:text-base">
                <div><span className="font-semibold">{filteredData.length}</span> รายการ</div>
                <div>ราคารวม: <span className="font-semibold">{formatPrice(totalCost)}</span> บาท</div>
            </div>
        </div>
    );
};


// ========== WEEKLY TAB ==========
interface WeeklyTabProps {
    data: RepairItem[];
    isMobile: boolean;
}

export const WeeklyTab: React.FC<WeeklyTabProps> = ({ data, isMobile }) => {
    const today = new Date();
    const [year, setYear] = useState(today.getFullYear());
    const [month, setMonth] = useState(today.getMonth());
    const [selectedWeek, setSelectedWeek] = useState<WeeklyData | null>(null);

    const { uniqueYears } = useMemo(() => {
        const years = new Set<number>();
        data.forEach(item => {
            const date = new Date(item['วันที่แจ้งซ่อม(APP)']);
            if (!isNaN(date.getTime())) years.add(date.getFullYear());
        });
        return { uniqueYears: Array.from(years).sort((a, b) => b - a) };
    }, [data]);

    const { weeklyReport, monthData } = useMemo(() => {
        const filtered = data.filter(item => {
            const date = parseDate(item['วันที่แจ้งซ่อม(APP)']);
            return date && date.getFullYear() === year && date.getMonth() === month;
        });
        return { weeklyReport: groupDataByWeek(filtered, year, month), monthData: filtered };
    }, [data, year, month]);

    const monthlyTotalCount = monthData.length;
    const monthlyTotalPrice = monthData.reduce((sum, item) => sum + calculateTotalCost(item), 0);
    const weeklyAvgCount = weeklyReport.length > 0 ? (monthlyTotalCount / weeklyReport.length) : 0;
    const weeklyAvgPrice = weeklyReport.length > 0 ? (monthlyTotalPrice / weeklyReport.length) : 0;
    
    const handleWeekSelect = (week: WeeklyData) => {
        setSelectedWeek(week);
    };

    if (selectedWeek) {
        return (
            <div>
                 <h3 className="font-semibold text-base sm:text-lg mb-3 sm:mb-4 text-slate-800">
                    รายละเอียดสัปดาห์ที่ {weeklyReport.findIndex(w => w.start === selectedWeek.start) + 1}
                    <span className="text-sm font-normal text-gray-600 ml-2">({formatDate(selectedWeek.start.toISOString())} - {formatDate(selectedWeek.end.toISOString())})</span>
                </h3>
                {isMobile ? (
                     <div>{selectedWeek.items.map((item, idx) => <RepairCard key={item['ลำดับที่']} item={item} index={idx+1} />)}</div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                            <thead>
                                <tr className="bg-slate-100">
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ลำดับที่</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">เบอร์รถ</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">รายการซ่อม</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ประเภท</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">วันที่แจ้งซ่อม</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-semibold text-slate-800 uppercase tracking-wider">ต้นทุนรวม</th>
                                </tr>
                            </thead>
                            <tbody>{selectedWeek.items.map((item, idx) => (
                                <tr key={item['ลำดับที่']} className="odd:bg-white even:bg-slate-50 hover:bg-blue-100/50 text-sm">
                                    <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{idx + 1}</td>
                                    <td className="border-b border-gray-200 px-4 py-3 text-slate-800 font-medium">{item['เบอร์รถ']}</td>
                                    <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{item['รายการซ่อม']}</td>
                                    <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{item['ประเภท']}</td>
                                    <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{formatDate(item['วันที่แจ้งซ่อม(APP)'])}</td>
                                    <td className="border-b border-gray-200 px-4 py-3 text-right font-bold text-emerald-600">{formatPrice(calculateTotalCost(item))}</td>
                                </tr>
                            ))}</tbody>
                        </table>
                    </div>
                )}
                <button onClick={() => setSelectedWeek(null)} className="mt-4 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md transition">กลับ</button>
            </div>
        )
    }

    return (
        <div>
            <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row gap-2">
                <select value={year} onChange={e => setYear(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                    {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
                <select value={month} onChange={e => setMonth(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                    {Array.from({ length: 12 }).map((_, i) => <option key={i} value={i}>{getThaiMonthName(i)}</option>)}
                </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
                <SummaryCard title="จำนวนรายการทั้งหมด" value={monthlyTotalCount} color="blue" />
                <SummaryCard title="ราคารวมทั้งหมด" value={formatPrice(monthlyTotalPrice)} unit="บาท" color="green" />
                <SummaryCard title="จำนวนเฉลี่ยต่อสัปดาห์" value={weeklyAvgCount.toFixed(1)} color="purple" />
                <SummaryCard title="ราคาเฉลี่ยต่อสัปดาห์" value={formatPrice(weeklyAvgPrice)} unit="บาท" color="amber" />
            </div>

            {weeklyReport.length === 0 ? <div className="text-center py-8 text-gray-500">ไม่พบข้อมูลในเดือนที่เลือก</div> : (
                <div className="bg-white rounded-lg shadow-md p-3 sm:p-4">
                    <h3 className="font-semibold text-base sm:text-lg mb-3 sm:mb-4 text-slate-800">รายงานรายสัปดาห์</h3>
                    {isMobile ? (
                        <div className="space-y-3">
                            {weeklyReport.map((week, index) => {
                                const totalCost = week.items.reduce((sum, item) => sum + calculateTotalCost(item), 0);
                                return (
                                <div key={index} onClick={() => handleWeekSelect(week)} className="mobile-card border border-gray-200 rounded-lg p-3 cursor-pointer hover:bg-gray-100/80 shadow-sm">
                                    <div className="flex justify-between items-center mb-1">
                                        <div className="font-semibold text-slate-800">สัปดาห์ที่ {index + 1}</div>
                                        <div className="text-right font-bold text-blue-800">{formatPrice(totalCost)}</div>
                                    </div>
                                    <div className="text-xs text-slate-500 mb-2">{formatDate(week.start.toISOString())} - {formatDate(week.end.toISOString())}</div>
                                    <div className="text-sm text-slate-700">จำนวน: <span className="font-semibold text-slate-900">{week.items.length} รายการ</span></div>
                                </div>
                            )})}
                        </div>
                    ) : (
                         <div className="overflow-x-auto">
                            <table className="w-full border-collapse">
                                <thead>
                                    <tr className="bg-slate-100">
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-semibold text-slate-800 uppercase tracking-wider">สัปดาห์</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-semibold text-slate-800 uppercase tracking-wider">ช่วงวันที่</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-semibold text-slate-800 uppercase tracking-wider">จำนวนรายการ</th>
                                        <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-semibold text-slate-800 uppercase tracking-wider">ราคารวม</th>
                                    </tr>
                                </thead>
                                <tbody>{weeklyReport.map((week, index) => {
                                     const totalCost = week.items.reduce((sum, item) => sum + calculateTotalCost(item), 0);
                                     return (
                                        <tr key={index} onClick={() => handleWeekSelect(week)} className="odd:bg-white even:bg-slate-50 hover:bg-blue-100/50 cursor-pointer text-sm">
                                            <td className="border-b border-gray-200 px-4 py-3 text-center font-medium text-slate-700">{index + 1}</td>
                                            <td className="border-b border-gray-200 px-4 py-3 text-slate-800">{formatDate(week.start.toISOString())} - {formatDate(week.end.toISOString())}</td>
                                            <td className="border-b border-gray-200 px-4 py-3 text-center text-slate-800 font-bold">{week.items.length}</td>
                                            <td className="border-b border-gray-200 px-4 py-3 text-right font-semibold text-blue-800">{formatPrice(totalCost)}</td>
                                        </tr>
                                     )
                                })}</tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};


// ========== TYPE TAB ==========
interface TypeTabProps {
    data: RepairItem[];
    isMobile: boolean;
}

const TypeRow: React.FC<{type: string, stats: TypeStats, isMobile: boolean, isExpanded: boolean, onToggle: () => void}> = ({ type, stats, isMobile, isExpanded, onToggle }) => {
    return(<>
        <tr onClick={onToggle} className="expandable-row odd:bg-white even:bg-slate-50 hover:bg-blue-100/50 cursor-pointer text-sm text-slate-700">
            <td className="border-b border-gray-200 px-4 py-3">
                <div className="flex items-center font-semibold text-slate-800">
                    <span className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}><Icons name="chevronDown" className="h-5 w-5 mr-1 text-slate-500" /></span>
                    {type}
                </div>
            </td>
            <td className="border-b border-gray-200 px-4 py-3 text-center"><span className="inline-flex items-center justify-center bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">{stats.regNumbers.size} คัน</span></td>
            <td className="border-b border-gray-200 px-4 py-3 text-center font-bold text-slate-900">{stats.count}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right font-semibold text-blue-800">{formatPrice(stats.totalCost)}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right text-slate-700">{formatPrice(stats.avgCost)}</td>
        </tr>
        {isExpanded && (
            <tr className="expandable-content expanded">
                <td colSpan={5} className="p-3 bg-blue-50/70 border-b-2 border-blue-100">
                    <div className="font-semibold mb-2 text-slate-700">หมายเลขทะเบียนรถ ({stats.regNumbers.size} คัน):</div>
                    <div className="flex flex-wrap gap-2">
                        {Array.from(stats.regNumbers).sort().map(reg => <span key={reg} className="bg-sky-100 text-sky-800 text-xs font-medium px-2.5 py-0.5 rounded-full">{reg}</span>)}
                    </div>
                </td>
            </tr>
        )}
    </>);
}

const TypeCard: React.FC<{type: string, stats: TypeStats, isExpanded: boolean, onToggle: () => void}> = ({ type, stats, isExpanded, onToggle }) => {
    return (
        <div className="mobile-card border border-gray-200 rounded-lg p-3 bg-white shadow-sm">
            <div onClick={onToggle} className="flex justify-between items-center cursor-pointer">
                <div className="font-semibold flex items-center text-slate-800">{type} 
                    <span className={`transform transition-transform duration-200 ml-2 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}>
                        <Icons name="chevronDown" className="h-5 w-5 text-slate-500"/>
                    </span>
                </div>
                <div className="text-right font-bold text-blue-800">{stats.count} รายการ</div>
            </div>
            <div className="text-sm text-slate-600 mt-1">ราคารวม: <span className="font-semibold text-slate-800">{formatPrice(stats.totalCost)}</span></div>
            {isExpanded && (
                 <div className="mt-3 pt-3 border-t border-gray-200">
                    <div className="font-semibold mb-2 text-sm text-slate-700">หมายเลขทะเบียนรถ ({stats.regNumbers.size} คัน):</div>
                    <div className="flex flex-wrap gap-1">
                        {Array.from(stats.regNumbers).sort().map(reg => <span key={reg} className="bg-sky-100 text-sky-800 text-xs font-medium px-2 py-0.5 rounded-full">{reg}</span>)}
                    </div>
                </div>
            )}
        </div>
    )
}

export const TypeTab: React.FC<TypeTabProps> = ({ data, isMobile }) => {
    const [period, setPeriod] = useState('all');
    const today = new Date();
    const [year, setYear] = useState(today.getFullYear());
    const [month, setMonth] = useState(today.getMonth());
    const [expandedTypes, setExpandedTypes] = useState<Set<string>>(new Set());

    const { uniqueYears } = useMemo(() => {
        const years = new Set<number>();
        data.forEach(item => { const date = new Date(item['วันที่แจ้งซ่อม(APP)']); if (!isNaN(date.getTime())) years.add(date.getFullYear()); });
        return { uniqueYears: Array.from(years).sort((a, b) => b - a) };
    }, [data]);

    const typeData = useMemo(() => {
        let filteredData = data;
        if (period === 'year') {
            filteredData = data.filter(item => { const d = parseDate(item['วันที่แจ้งซ่อม(APP)']); return d && d.getFullYear() === year; });
        } else if (period === 'month') {
            filteredData = data.filter(item => { const d = parseDate(item['วันที่แจ้งซ่อม(APP)']); return d && d.getFullYear() === year && d.getMonth() === month; });
        }
        return processTypeData(filteredData);
    }, [data, period, year, month]);

    const sortedTypes = useMemo(() => Object.entries(typeData).sort(([, a], [, b]) => b.count - a.count), [typeData]);
    const totalItems = useMemo(() => sortedTypes.reduce((sum, [, stats]) => sum + stats.count, 0), [sortedTypes]);
    const totalPrice = useMemo(() => sortedTypes.reduce((sum, [, stats]) => sum + stats.totalCost, 0), [sortedTypes]);

    const countChartData = sortedTypes.slice(0, 10).map(([type, stats]) => ({ label: type, value: stats.count, displayValue: `${stats.count}` }));
    const priceChartData = [...sortedTypes].sort(([,a], [,b]) => b.totalCost - a.totalCost).slice(0, 10).map(([type, stats]) => ({ label: type, value: stats.totalCost, displayValue: formatPrice(stats.totalCost) }));
    
    const toggleType = (type: string) => {
        setExpandedTypes(prev => {
            const newSet = new Set(prev);
            if (newSet.has(type)) newSet.delete(type); else newSet.add(type);
            return newSet;
        });
    };

    return (
        <div>
            <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row gap-2">
                <select value={period} onChange={e => setPeriod(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md">
                    <option value="all">ทั้งหมด</option><option value="year">รายปี</option><option value="month">รายเดือน</option>
                </select>
                {period === 'year' && (
                    <select value={year} onChange={e => setYear(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                        {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                )}
                 {period === 'month' && (<>
                    <select value={year} onChange={e => setYear(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                        {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                    <select value={month} onChange={e => setMonth(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                        {Array.from({ length: 12 }).map((_, i) => <option key={i} value={i}>{getThaiMonthName(i)}</option>)}
                    </select>
                </>)}
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
                <SummaryCard title="จำนวนประเภทการซ่อม" value={sortedTypes.length} color="blue" />
                <SummaryCard title="จำนวนรายการทั้งหมด" value={totalItems} color="green" />
                <SummaryCard title="ราคารวมทั้งหมด" value={formatPrice(totalPrice)} unit="บาท" color="purple" />
                <SummaryCard title="ราคาเฉลี่ยต่อรายการ" value={formatPrice(totalItems > 0 ? totalPrice / totalItems : 0)} unit="บาท" color="amber" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                <BarChart data={countChartData} color="bg-blue-500" title="จำนวนรายการตามประเภท (Top 10)" />
                <BarChart data={priceChartData} color="bg-green-500" title="ราคารวมตามประเภท (Top 10)" />
            </div>

            <div className="bg-white rounded-lg shadow-md p-3 sm:p-4">
                <h3 className="font-semibold text-base sm:text-lg mb-3 sm:mb-4 text-slate-800">รายละเอียดตามประเภทการซ่อม</h3>
                {isMobile ? (
                    <div className="space-y-3">
                        {sortedTypes.map(([type, stats]) => <TypeCard key={type} type={type} stats={stats} isExpanded={expandedTypes.has(type)} onToggle={() => toggleType(type)} />)}
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                            <thead>
                                <tr className="bg-slate-100">
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-bold text-slate-800 uppercase tracking-wider">ประเภท</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-bold text-slate-800 uppercase tracking-wider">จำนวนรถ</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-bold text-slate-800 uppercase tracking-wider">จำนวนรายการ</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-bold text-slate-800 uppercase tracking-wider">ราคารวม</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-bold text-slate-800 uppercase tracking-wider">ราคาเฉลี่ย</th>
                                </tr>
                            </thead>
                            <tbody>{sortedTypes.map(([type, stats]) => <TypeRow key={type} type={type} stats={stats} isMobile={isMobile} isExpanded={expandedTypes.has(type)} onToggle={() => toggleType(type)} /> )}</tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};

// ========== VEHICLE TAB ==========
interface VehicleTabProps {
    data: RepairItem[];
    isMobile: boolean;
}

const VehicleRow: React.FC<{rank: number, vehicle: string, stats: VehicleStats, isExpanded: boolean, onToggle: () => void}> = ({ rank, vehicle, stats, isExpanded, onToggle }) => {
    const groupedItems = useMemo(() => {
        if (!isExpanded) return [];

        const groups: { [key: string]: RepairItem[] } = {};
        stats.items.forEach(item => {
            const type = item['ประเภท'] || 'ไม่ระบุ';
            if (!groups[type]) {
                groups[type] = [];
            }
            groups[type].push(item);
        });

        for (const type in groups) {
            groups[type].sort((a, b) => {
                const dateA = parseDate(a['วันที่แจ้งซ่อม(APP)']);
                const dateB = parseDate(b['วันที่แจ้งซ่อม(APP)']);
                if (!dateA) return 1;
                if (!dateB) return -1;
                return dateB.getTime() - dateA.getTime();
            });
        }
        
        return Object.entries(groups).sort(([, itemsA], [, itemsB]) => itemsB.length - itemsA.length);
        
    }, [stats.items, isExpanded]);
    
    return(<>
        <tr onClick={onToggle} className="expandable-row odd:bg-white even:bg-slate-50 hover:bg-blue-100/50 cursor-pointer text-sm">
            <td className="border-b border-gray-200 px-4 py-3 text-center text-slate-700">
                <div className="flex items-center justify-center">
                     <span className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}><Icons name="chevronDown" className="h-5 w-5 mr-1 text-slate-500" /></span>
                     {rank}
                </div>
            </td>
            <td className="border-b border-gray-200 px-4 py-3 font-semibold text-slate-800">{vehicle}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-center font-bold text-slate-800">{stats.count}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right font-semibold text-blue-800">{formatPrice(stats.totalCost)}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-right text-slate-700">{formatPrice(stats.avgCost)}</td>
            <td className="border-b border-gray-200 px-4 py-3 text-slate-700">{stats.mostCommonType}</td>
        </tr>
        {isExpanded && (
            <tr className="expandable-content expanded">
                <td colSpan={6} className="p-1 sm:p-2 bg-blue-50/70">
                    <div className="p-2 bg-white rounded-md shadow-inner">
                        <h4 className="font-semibold text-blue-800 mb-3 text-base">รายการซ่อมของรถ: {vehicle}</h4>
                        <div className="space-y-4">
                            {groupedItems.map(([type, items]) => (
                                <div key={type}>
                                    <div className="bg-gradient-to-r from-slate-100 to-slate-50 px-3 py-2 rounded-t-lg border-l-4 border-slate-400">
                                        <div className="flex justify-between items-center">
                                            <div className="font-semibold text-slate-700">{type}</div>
                                            <div className="text-sm font-medium text-slate-600">{items.length} รายการ</div>
                                        </div>
                                    </div>
                                    <div className="divide-y divide-gray-200">
                                        {items.map(item => (
                                            <div key={item['ลำดับที่']} className="text-sm py-3 px-3 hover:bg-slate-50">
                                                <div className="flex justify-between items-start">
                                                    <div>
                                                        <div className="font-medium text-slate-800">{item['รายการซ่อม']}</div>
                                                        <div className="text-slate-600 text-xs mt-1">{formatDate(item['วันที่แจ้งซ่อม(APP)'])}</div>
                                                    </div>
                                                    <div className="font-bold text-emerald-600 text-right whitespace-nowrap pl-4">{formatPrice(calculateTotalCost(item))}</div>
                                                </div>
                                                {item['รายการอะไหล่ที่ต้องเปลี่ยน'] && 
                                                    <div className="text-slate-500 text-xs mt-2 pt-2 border-t border-gray-100">
                                                        <span className="font-medium">อะไหล่:</span> {item['รายการอะไหล่ที่ต้องเปลี่ยน']} ({formatPrice(calculateTotalSparePartsPrice(item['ราคาอะไหล่']))})
                                                    </div>
                                                }
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </td>
            </tr>
        )}
    </>)
}

const VehicleCard: React.FC<{rank: number, vehicle: string, stats: VehicleStats, isExpanded: boolean, onToggle: () => void}> = ({ rank, vehicle, stats, isExpanded, onToggle }) => {
    const groupedItems = useMemo(() => {
        if (!isExpanded) return [];

        const groups: { [key: string]: RepairItem[] } = {};
        stats.items.forEach(item => {
            const type = item['ประเภท'] || 'ไม่ระบุ';
            if (!groups[type]) {
                groups[type] = [];
            }
            groups[type].push(item);
        });

        for (const type in groups) {
            groups[type].sort((a, b) => {
                const dateA = parseDate(a['วันที่แจ้งซ่อม(APP)']);
                const dateB = parseDate(b['วันที่แจ้งซ่อม(APP)']);
                if (!dateA) return 1;
                if (!dateB) return -1;
                return dateB.getTime() - dateA.getTime();
            });
        }
        
        return Object.entries(groups).sort(([, itemsA], [, itemsB]) => itemsB.length - itemsA.length);
        
    }, [stats.items, isExpanded]);
    
    return (
        <div className="mobile-card border border-gray-200 rounded-lg bg-white shadow-sm mb-3">
             <div onClick={onToggle} className="p-3 cursor-pointer hover:bg-gray-50">
                <div className="flex justify-between items-center">
                    <div className="font-semibold flex items-center text-slate-800">
                        <span className="text-slate-500 font-normal mr-2">#{rank}</span>
                        {vehicle}
                    </div>
                    <div className="flex items-center">
                        <div className="text-right font-bold text-blue-800">{stats.count} ครั้ง</div>
                        <span className={`transform transition-transform duration-200 ml-2 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}>
                            <Icons name="chevronDown" className="h-5 w-5 text-slate-500"/>
                        </span>
                    </div>
                </div>
                <div className="text-sm text-slate-600 mt-1">ราคารวม: <span className="font-semibold text-slate-800">{formatPrice(stats.totalCost)}</span></div>
            </div>
            {isExpanded && (
                <div className="px-3 pb-3 border-t border-gray-200">
                    <div className="pt-3">
                        <h4 className="font-semibold text-blue-800 mb-2 text-sm">รายการซ่อม (จัดกลุ่มตามประเภท)</h4>
                         <div className="space-y-3">
                            {groupedItems.map(([type, items]) => (
                                <div key={type} className="bg-slate-50 p-2 rounded">
                                    <div className="font-semibold text-slate-700 text-xs mb-2">{type} ({items.length})</div>
                                    <div className="space-y-2">
                                        {items.map(item => (
                                            <div key={item['ลำดับที่']} className="text-xs border-t first:border-t-0 pt-2 first:pt-0">
                                                <div className="flex justify-between">
                                                    <div>
                                                        <div className="font-medium text-slate-800">{item['รายการซ่อม']}</div>
                                                        <div className="text-slate-500 mt-0.5">{formatDate(item['วันที่แจ้งซ่อม(APP)'])}</div>
                                                    </div>
                                                    <div className="font-bold text-emerald-600 text-right">{formatPrice(calculateTotalCost(item))}</div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}


export const VehicleTab: React.FC<VehicleTabProps> = ({ data, isMobile }) => {
    const [period, setPeriod] = useState('all');
    const [sortBy, setSortBy] = useState('count');
    const today = new Date();
    const [year, setYear] = useState(today.getFullYear());
    const [month, setMonth] = useState(today.getMonth());
    const [expandedVehicles, setExpandedVehicles] = useState<Set<string>>(new Set());

    const { uniqueYears } = useMemo(() => {
        const years = new Set<number>();
        data.forEach(item => { const date = new Date(item['วันที่แจ้งซ่อม(APP)']); if (!isNaN(date.getTime())) years.add(date.getFullYear()); });
        return { uniqueYears: Array.from(years).sort((a, b) => b - a) };
    }, [data]);

    const vehicleData = useMemo(() => {
        let filteredData = data;
        if (period === 'year') {
            filteredData = data.filter(item => { const d = parseDate(item['วันที่แจ้งซ่อม(APP)']); return d && d.getFullYear() === year; });
        } else if (period === 'month') {
            filteredData = data.filter(item => { const d = parseDate(item['วันที่แจ้งซ่อม(APP)']); return d && d.getFullYear() === year && d.getMonth() === month; });
        }
        return processVehicleData(filteredData);
    }, [data, period, year, month]);

    const sortedVehicles = useMemo(() => Object.entries(vehicleData).sort(([, a], [, b]) => {
        if(sortBy === 'count') return b.count - a.count;
        return b.totalCost - a.totalCost;
    }), [vehicleData, sortBy]);
    
    const countChartData = [...sortedVehicles].sort(([,a],[,b])=>b.count - a.count).slice(0, 10).map(([vehicle, stats]) => ({ label: vehicle, value: stats.count, displayValue: `${stats.count} ครั้ง` }));
    const priceChartData = [...sortedVehicles].sort(([,a],[,b])=>b.totalCost - a.totalCost).slice(0, 10).map(([vehicle, stats]) => ({ label: vehicle, value: stats.totalCost, displayValue: formatPrice(stats.totalCost) }));
    
    const toggleVehicle = (vehicle: string) => {
        setExpandedVehicles(prev => {
            const newSet = new Set(prev);
            if (newSet.has(vehicle)) newSet.delete(vehicle); else newSet.add(vehicle);
            return newSet;
        });
    };

     return (
        <div>
            <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row gap-2">
                <select value={period} onChange={e => setPeriod(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md">
                    <option value="all">ทั้งหมด</option><option value="year">รายปี</option><option value="month">รายเดือน</option>
                </select>
                 {period !== 'all' && (<>
                    <select value={year} onChange={e => setYear(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                        {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                    {period === 'month' && (
                        <select value={month} onChange={e => setMonth(Number(e.target.value))} className="px-3 py-2 border border-gray-300 rounded-md">
                        {Array.from({ length: 12 }).map((_, i) => <option key={i} value={i}>{getThaiMonthName(i)}</option>)}
                    </select>
                    )}
                </>)}
                 <select value={sortBy} onChange={e => setSortBy(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-md">
                    <option value="count">เรียงตามจำนวนครั้ง</option><option value="price">เรียงตามราคารวม</option>
                </select>
            </div>
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                <BarChart data={countChartData} color="bg-blue-500" title="จำนวนครั้งการซ่อม (Top 10)" />
                <BarChart data={priceChartData} color="bg-green-500" title="ค่าใช้จ่ายรวม (Top 10)" />
            </div>
             <div className="bg-white rounded-lg shadow-md p-3 sm:p-4">
                 <h3 className="font-semibold text-base sm:text-lg mb-3 sm:mb-4 text-slate-800">รายละเอียดสถิติรถ</h3>
                {isMobile ? (
                    <div className="space-y-0">
                        {sortedVehicles.map(([vehicle, stats], index) => (
                            <VehicleCard 
                                key={vehicle} 
                                rank={index + 1} 
                                vehicle={vehicle} 
                                stats={stats} 
                                isExpanded={expandedVehicles.has(vehicle)} 
                                onToggle={() => toggleVehicle(vehicle)} 
                            />
                        ))}
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                            <thead>
                                <tr className="bg-slate-100">
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-bold text-slate-800 uppercase tracking-wider">อันดับ</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-bold text-slate-800 uppercase tracking-wider">เบอร์รถ</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-center text-sm font-bold text-slate-800 uppercase tracking-wider">จำนวนครั้ง</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-bold text-slate-800 uppercase tracking-wider">ราคารวม</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-right text-sm font-bold text-slate-800 uppercase tracking-wider">ราคาเฉลี่ย</th>
                                    <th className="border-b-2 border-gray-200 px-4 py-3 text-left text-sm font-bold text-slate-800 uppercase tracking-wider">ประเภทหลัก</th>
                                </tr>
                            </thead>
                            <tbody>{sortedVehicles.map(([vehicle, stats], index) => <VehicleRow key={vehicle} rank={index+1} vehicle={vehicle} stats={stats} isExpanded={expandedVehicles.has(vehicle)} onToggle={()=>toggleVehicle(vehicle)} /> )}</tbody>
                        </table>
                    </div>
                )}
             </div>
        </div>
    );
};