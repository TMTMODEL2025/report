
import { RepairItem, WeeklyData, TypeStats, VehicleStats } from './types';

export const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwp0yu3ryGYYaaSIkTkOs64BFI3CYllPcQPJe3HcpldhPqHnggmmjTC1uSOV_xHLpUh/exec';

export const fetchData = async (): Promise<RepairItem[]> => {
    const response = await fetch(SCRIPT_URL);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (!Array.isArray(data)) {
        throw new Error('Data is not an array');
    }
    return data;
};

export const parseDate = (dateString: string): Date | null => {
    if (!dateString) return null;

    const date = new Date(dateString);

    // Check if parsing failed
    if (isNaN(date.getTime())) {
        return null;
    }

    // Heuristic to detect if the year was parsed as a Buddhist Era year.
    // e.g. "2567-01-01" gets parsed as year 2567 AD. We need to convert it back to Gregorian.
    // A threshold like 2200 should be safe enough.
    if (date.getFullYear() > 2200) {
        date.setFullYear(date.getFullYear() - 543);
    }
    
    return date;
};


export const formatDate = (dateString: string): string => {
    if (!dateString) return '';
    const date = parseDate(dateString);
    if (!date) return '';
    return date.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
};

export const formatPrice = (price: number | string | null | undefined): string => {
    const num = Number(price);
    if (price === null || price === undefined || isNaN(num) || !isFinite(num)) return '-';
    return num.toLocaleString('th-TH', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
};

export const getThaiMonthName = (monthIndex: number): string => {
    const months = [
        'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
        'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
    ];
    return months[monthIndex];
};


export const calculateTotalSparePartsPrice = (priceString: string | number): number => {
    if (!priceString) return 0;
    const s = String(priceString);
    const prices = s.split(/[,;|+]/).map(p => parseFloat(p.trim())).filter(p => !isNaN(p));
    return prices.reduce((sum, current) => sum + current, 0);
};

export const calculateTotalCost = (item: RepairItem): number => {
    const sparePartsPrice = calculateTotalSparePartsPrice(item['ราคาอะไหล่']);
    const servicePrice = parseFloat(String(item['ราคา'])) || 0;
    return sparePartsPrice + servicePrice;
};

export const groupDataByMonth = (data: RepairItem[]) => {
    const grouped: { [key: string]: { items: RepairItem[], totalPrice: number, year: number, month: number } } = {};

    const sortedData = [...data].sort((a, b) => {
        const dateA = parseDate(a['วันที่แจ้งซ่อม(APP)']) || new Date(0);
        const dateB = parseDate(b['วันที่แจ้งซ่อม(APP)']) || new Date(0);
        return dateB.getTime() - dateA.getTime();
    });

    sortedData.forEach(item => {
        const date = parseDate(item['วันที่แจ้งซ่อม(APP)']);
        if (!date) return;

        const year = date.getFullYear();
        const month = date.getMonth();
        const key = `${year}-${month}`;

        if (!grouped[key]) {
            grouped[key] = { items: [], totalPrice: 0, year, month };
        }
        grouped[key].items.push(item);
        grouped[key].totalPrice += calculateTotalCost(item);
    });

    return grouped;
};

export const groupDataByWeek = (data: RepairItem[], year: number, month: number): WeeklyData[] => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const weeks: WeeklyData[] = [];
    let currentWeekStart = new Date(firstDay);
    currentWeekStart.setDate(currentWeekStart.getDate() - firstDay.getDay());

    while (currentWeekStart <= lastDay) {
        const weekEnd = new Date(currentWeekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);
        weeks.push({ start: new Date(currentWeekStart), end: new Date(weekEnd), items: [] });
        currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    }

    data.forEach(item => {
        const date = parseDate(item['วันที่แจ้งซ่อม(APP)']);
        if (!date) return;
        for (const week of weeks) {
            const weekEndMidnight = new Date(week.end);
            weekEndMidnight.setHours(23, 59, 59, 999);
            if (date >= week.start && date <= weekEndMidnight) {
                week.items.push(item);
                break;
            }
        }
    });

    return weeks.filter(w => w.items.length > 0);
};

export const processTypeData = (data: RepairItem[]): { [key: string]: TypeStats } => {
    const stats: { [key: string]: TypeStats } = {};
    const totalItemCount = data.length;

    data.forEach(item => {
        const type = item['ประเภท'] || 'ไม่ระบุ';
        const cost = calculateTotalCost(item);

        if (!stats[type]) {
            stats[type] = {
                count: 0,
                totalCost: 0,
                minCost: Infinity,
                maxCost: -Infinity,
                items: [],
                regNumbers: new Set(),
                avgCost: 0,
                percentage: 0
            };
        }

        stats[type].count++;
        stats[type].totalCost += cost;
        stats[type].minCost = Math.min(stats[type].minCost, cost);
        stats[type].maxCost = Math.max(stats[type].maxCost, cost);
        stats[type].items.push(item);
        if (item['เบอร์รถ']) {
            stats[type].regNumbers.add(item['เบอร์รถ']);
        }
    });

    Object.keys(stats).forEach(type => {
        stats[type].avgCost = stats[type].count > 0 ? stats[type].totalCost / stats[type].count : 0;
        stats[type].percentage = totalItemCount > 0 ? (stats[type].count / totalItemCount) * 100 : 0;
        if(stats[type].minCost === Infinity) stats[type].minCost = 0;
    });

    return stats;
};


export const processVehicleData = (data: RepairItem[]): { [key: string]: VehicleStats } => {
    const stats: { [key: string]: VehicleStats } = {};

    data.forEach(item => {
        const vehicleNumber = item['เบอร์รถ'] || 'ไม่ระบุ';
        if (vehicleNumber === 'ไม่ระบุ') return;

        const cost = calculateTotalCost(item);
        const servicePrice = parseFloat(String(item['ราคา'])) || 0;

        if (!stats[vehicleNumber]) {
            stats[vehicleNumber] = {
                count: 0,
                totalPrice: 0,
                totalCost: 0,
                minCost: Infinity,
                maxCost: -Infinity,
                items: [],
                types: {},
                avgCost: 0,
                mostCommonType: ''
            };
        }

        stats[vehicleNumber].count++;
        stats[vehicleNumber].totalPrice += servicePrice;
        stats[vehicleNumber].totalCost += cost;
        stats[vehicleNumber].minCost = Math.min(stats[vehicleNumber].minCost, cost);
        stats[vehicleNumber].maxCost = Math.max(stats[vehicleNumber].maxCost, cost);
        stats[vehicleNumber].items.push(item);
        
        const type = item['ประเภท'] || 'ไม่ระบุ';
        stats[vehicleNumber].types[type] = (stats[vehicleNumber].types[type] || 0) + 1;
    });

    Object.keys(stats).forEach(vehicle => {
        stats[vehicle].avgCost = stats[vehicle].count > 0 ? stats[vehicle].totalCost / stats[vehicle].count : 0;
        
        let maxTypeCount = 0;
        let mostCommonType = 'ไม่ระบุ';
        Object.entries(stats[vehicle].types).forEach(([type, count]) => {
            if (count > maxTypeCount) {
                mostCommonType = type;
                maxTypeCount = count;
            }
        });
        stats[vehicle].mostCommonType = mostCommonType;
         if(stats[vehicle].minCost === Infinity) stats[vehicle].minCost = 0;
    });

    return stats;
};

export const getSplitArray = (value: string | number | undefined): string[] => {
    if (!value) return [''];
    const strValue = String(value);
    const separators = [',', ';', '|', '+'];
    for (const sep of separators) {
        if (strValue.includes(sep)) {
            return strValue.split(sep).map(item => item.trim()).filter(Boolean);
        }
    }
    return [strValue];
};
