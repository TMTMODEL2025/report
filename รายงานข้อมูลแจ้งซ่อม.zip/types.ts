
export interface RepairItem {
  'ลำดับที่': number;
  'เบอร์รถ': string;
  'รายการซ่อม': string;
  'ประเภท': string;
  'เลขที่ใบแจ้งซ่อม(APP)': string;
  'เลขที่ใบแจ้งซ่อม(SAP)': string;
  'วันที่เปิดเอกสาร(SAP)': string;
  'วันที่แจ้งซ่อม(APP)': string;
  'ซ่อมเสร็จ(APP)': string;
  'รายการอะไหล่ที่ต้องเปลี่ยน': string;
  'ราคาอะไหล่': string | number;
  'ราคา': string | number;
}

export interface MonthlyGroup {
  items: RepairItem[];
  totalPrice: number;
  year: number;
  month: number;
}

export interface WeeklyData {
    start: Date;
    end: Date;
    items: RepairItem[];
}

export interface TypeStats {
    count: number;
    totalCost: number;
    minCost: number;
    maxCost: number;
    items: RepairItem[];
    regNumbers: Set<string>;
    avgCost: number;
    percentage: number;
}

export interface VehicleStats {
    count: number;
    totalPrice: number;
    totalCost: number;
    minCost: number;
    maxCost: number;
    items: RepairItem[];
    types: { [key: string]: number };
    avgCost: number;
    mostCommonType: string;
}

export enum Tab {
    All = 'all',
    Weekly = 'weekly',
    Type = 'type',
    Vehicle = 'vehicle'
}
