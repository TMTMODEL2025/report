import React, { useState, useEffect, useMemo } from 'react';
import { Tab, RepairItem } from './types';
import { fetchData, SCRIPT_URL } from './utils';
import { AllDataTab, WeeklyTab, TypeTab, VehicleTab, Loader, Icons } from './components';

const App: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>(Tab.All);
    const [allData, setAllData] = useState<RepairItem[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const loadData = () => {
        setLoading(true);
        setError(null);
        fetchData()
            .then(data => {
                setAllData(data);
                setLoading(false);
            })
            .catch(err => {
                console.error(err);
                setError('ไม่สามารถโหลดข้อมูลได้ กรุณาลองใหม่อีกครั้ง');
                setLoading(false);
            });
    };

    useEffect(loadData, []);
    
    const testConnection = async () => {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
            const response = await fetch(SCRIPT_URL, { signal: controller.signal });
            clearTimeout(timeoutId);
            if(response.ok) {
                alert(`การเชื่อมต่อสำเร็จ! (สถานะ: ${response.status})`);
            } else {
                alert(`การเชื่อมต่อล้มเหลว (สถานะ: ${response.status})`);
            }
        } catch (error: any) {
            if (error.name === 'AbortError') {
                 alert('การทดสอบการเชื่อมต่อใช้เวลานานเกินไป');
            } else {
                 alert(`การทดสอบการเชื่อมต่อล้มเหลว: ${error.message}`);
            }
        }
    }

    const tabConfig = [
        { id: Tab.All, label: 'ข้อมูลทั้งหมด' },
        { id: Tab.Weekly, label: 'รายสัปดาห์' },
        { id: Tab.Type, label: 'สรุปประเภท' },
        { id: Tab.Vehicle, label: 'สถิติรถ' }
    ];

    const renderContent = () => {
        if (loading) return <Loader />;
        if (error) return <div className="text-center py-8 text-red-500">{error}</div>;
        if (allData.length === 0) return <div className="text-center py-8 text-gray-500">ไม่พบข้อมูล</div>;

        switch (activeTab) {
            case Tab.All: return <AllDataTab data={allData} isMobile={isMobile} />;
            case Tab.Weekly: return <WeeklyTab data={allData} isMobile={isMobile} />;
            case Tab.Type: return <TypeTab data={allData} isMobile={isMobile} />;
            case Tab.Vehicle: return <VehicleTab data={allData} isMobile={isMobile} />;
            default: return null;
        }
    };

    return (
        <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
            <div className="bg-white rounded-lg shadow-lg p-3 sm:p-6 mb-6">
                <div className="flex flex-col sm:flex-row justify-between items-center mb-4">
                    <h1 className="text-xl sm:text-2xl font-bold text-center text-blue-800 mb-4 sm:mb-0">
                        รายงานข้อมูลแจ้งซ่อม
                    </h1>
                     <div className="flex gap-2">
                         <button onClick={loadData} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-md transition text-sm flex items-center justify-center">
                            <Icons name="refresh" className="h-4 w-4 mr-1"/> รีเฟรช
                        </button>
                        <button onClick={testConnection} className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-1.5 rounded-md transition text-sm flex items-center justify-center">
                            <Icons name="test" className="h-4 w-4 mr-1"/> ทดสอบ
                        </button>
                     </div>
                </div>

                <div className="flex border-b border-gray-200 mb-4 sm:mb-6 overflow-x-auto">
                    {tabConfig.map(tab => (
                        <div
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`tab py-2 px-3 sm:px-4 cursor-pointer font-medium whitespace-nowrap text-sm sm:text-base ${activeTab === tab.id ? 'border-b-[3px] border-blue-600 text-blue-800' : 'text-gray-500 hover:bg-blue-50'}`}
                        >
                            {tab.label}
                        </div>
                    ))}
                </div>
                
                {renderContent()}
            </div>
        </div>
    );
};

export default App;