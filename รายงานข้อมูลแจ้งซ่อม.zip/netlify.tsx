/*
# This configuration is for deploying a Single-Page Application (SPA) on Netlify.
# It ensures that all requests are redirected to the main index.html file,
# allowing the client-side router (React Router) to handle the page navigation.

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
*/